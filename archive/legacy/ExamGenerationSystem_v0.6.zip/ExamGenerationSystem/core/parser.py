import re
import random


class Question:
    def __init__(self, index, content, choices, correct_idx, solution):
        self.index = index
        self.content = content.strip()
        self.choices = choices  # 儲存選項文字內容的清單
        self.correct_idx = correct_idx  # 0~3 對應 A~D
        self.solution = solution.strip()

    def swap_answer(self, target_letter):
        """
        核心物理搬運邏輯：
        直接對調 choices 清單中的文字字串，而非移動標籤。
        """
        target_idx = ord(target_letter.upper()) - 65
        if 0 <= target_idx < len(self.choices) and 0 <= self.correct_idx < len(self.choices):
            if target_idx == self.correct_idx: return
            # 物理對調文字內容
            self.choices[self.correct_idx], self.choices[target_idx] = \
                self.choices[target_idx], self.choices[self.correct_idx]
            self.correct_idx = target_idx

    def to_latex(self):
        """
        產出符合 midterm_base.tex 期待的題目格式。
        """
        choice_latex = "\\begin{choices}\n"
        for i, text in enumerate(self.choices):
            # 產出時統一使用 \choice，正確答案標記由 \CorrectChoice 處理
            # 注意：這裡不區分模式，因為正確答案是由 correct_idx 決定的文字內容
            cmd = "\\CorrectChoice" if i == self.correct_idx else "\\choice"
            choice_latex += f"  {cmd} {text}\n"
        choice_latex += "\\end{choices}"

        return f"\\question {self.content}\n{choice_latex}\n\\begin{{solution}} {self.solution} \\end{{solution}}\n"


def balance_answers(questions):
    """
    執行全自動答案平衡。
    """
    if not questions: return questions
    total = len(questions)
    # 建立 ABCD 循環池
    pool = (['A', 'B', 'C', 'D'] * (total // 4 + 1))[:total]
    random.shuffle(pool)
    for q, target in zip(questions, pool):
        q.swap_answer(target)
    return questions


def parse_latex_file(file_path):
    """
    從 .tex 檔案中解析題目。
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            full_text = f.read()
    except Exception as e:
        print(f"讀取檔案錯誤: {e}")
        return []

    # 根據 \question 分割
    raw_qs = re.split(r'\\question', full_text)[1:]
    parsed_questions = []

    for i, raw in enumerate(raw_qs, 1):
        # 提取解析 (solution)
        sol_match = re.search(r'\\begin\{solution\}(.*?)\\end\{solution\}', raw, re.DOTALL)
        sol_text = sol_match.group(1) if sol_match else ""

        # 移除解析部分後處理題幹與選項
        body = re.sub(r'\\begin\{solution\}.*?\\end\{solution\}', '', raw, flags=re.DOTALL)

        # 提取選項區
        choice_block = re.search(r'\\begin\{choices\}(.*?)\\end\{choices\}', body, re.DOTALL)
        if choice_block:
            # 抓取 \choice 或 \CorrectChoice 及其內容
            items = re.findall(r'\\(choice|CorrectChoice)\s*(.*?)(?=\\choice|\\CorrectChoice|\\end\{choices\}|$)',
                               choice_block.group(1), re.DOTALL)

            choices = [it[1].strip() for it in items]
            # 找出原始檔案中標記為正確的索引
            c_idx = 0
            for idx, (cmd, _) in enumerate(items):
                if cmd == "CorrectChoice":
                    c_idx = idx
                    break

            # 題幹文字（排除選項區）
            q_text = body.split('\\begin{choices}')[0].strip()
            parsed_questions.append(Question(i, q_text, choices, c_idx, sol_text))

    return parsed_questions