import subprocess
import os
import shutil
from jinja2 import Template
from jinja2 import Environment, FileSystemLoader

class LaTeXCompiler:
    def __init__(self, output_dir="outputs"):
        self.output_dir = output_dir
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)

    def render_template(self, template_path, data, output_filename):
        template_dir = os.path.dirname(template_path)
        template_file = os.path.basename(template_path)

        # 重新定義定界符，避開 {{ }}
        env = Environment(
            loader=FileSystemLoader(template_dir),
            block_start_string='[%',
            block_end_string='%]',
            variable_start_string='[[',
            variable_end_string=']]',
            autoescape=False
        )

        template = env.get_template(template_file)
        rendered_tex = template.render(**data)

        output_path = os.path.join(self.output_dir, output_filename)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(rendered_tex)
        return output_filename

    def compile(self, tex_filename):
        """
        執行 xelatex 二次編譯邏輯
        """
        tex_path = os.path.join(self.output_dir, tex_filename)
        # 取得不含副檔名的檔名，用於清理中間檔案
        base_name = os.path.splitext(tex_filename)[0]

        # 定義編譯指令
        # -interaction=nonstopmode: 遇到錯誤不停止，方便自動化處理
        cmd = [
            "xelatex",
            "-interaction=nonstopmode",
            f"-output-directory={self.output_dir}",
            tex_path
        ]

        try:
            print(f"正在進行第一次編譯：{tex_filename}...")
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)

            print(f"正在進行第二次編譯（校正頁碼與統計）：{tex_filename}...")
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)

            print(f"🎉 {base_name}.pdf 生成成功！")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ 編譯失敗，請檢查 LaTeX 語法錯誤。錯誤碼: {e.returncode}")
            return False

    def copy_figures(self, source_dir):
        """
        自動拷貝圖片資料夾，確保編譯時能找到圖片路徑
        """
        target_fig_dir = os.path.join(self.output_dir, "figures")
        if os.path.exists(source_dir):
            shutil.copytree(source_dir, target_fig_dir, dirs_exist_ok=True)
            print(f"✅ 圖片資料夾已同步至: {target_fig_dir}")