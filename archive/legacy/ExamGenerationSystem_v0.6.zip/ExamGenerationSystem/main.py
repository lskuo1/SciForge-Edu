from ui.main_window import ExamGeneratorApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    # 設定視窗初始大小
    root.geometry("800x600")
    app = ExamGeneratorApp(root)
    root.mainloop()