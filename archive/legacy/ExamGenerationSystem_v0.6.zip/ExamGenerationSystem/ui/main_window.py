import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import sys
import random
from decimal import Decimal

# 確保專案路徑正確
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '..'))
if project_root not in sys.path:
    sys.path.append(project_root)

from core.parser import parse_latex_file, balance_answers
from core.compiler import LaTeXCompiler


class ExamGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("永豐高中理化科 - 考卷自動化系統 (Final Stable 2.7)")
        self.root.geometry("1500x980")

        self.compiler = LaTeXCompiler(output_dir="outputs")
        self.all_questions = []
        self.current_q_idx = -1
        self.vars = {}

        self.setup_ui()

    def setup_ui(self):
        # --- 1. 頂部工具列 ---
        top_bar = ttk.Frame(self.root);
        top_bar.pack(side="top", fill="x", padx=10, pady=5)
        ttk.Button(top_bar, text="➕ 載入題目", command=self.add_files).pack(side="left", padx=5)

        self.shuffle_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(top_bar, text="分組內隨機打亂題目", variable=self.shuffle_var).pack(side="left", padx=15)

        self.lbl_total_score = ttk.Label(top_bar, text="總分: 0 / 100", font=("Arial", 14, "bold"), foreground="red")
        self.lbl_total_score.pack(side="right", padx=20)

        # --- 2. 行政資訊區 (兩列排版) ---
        info_panel = ttk.LabelFrame(self.root, text=" 試卷行政資訊與計分說明設定 ")
        info_panel.pack(padx=10, pady=5, fill="x")

        row1 = ttk.Frame(info_panel);
        row1.pack(fill="x", pady=5)
        row2 = ttk.Frame(info_panel);
        row2.pack(fill="x", pady=5)

        # 行政欄位預設值 (依照老師提供之規範)
        configs = [
            ("school_name", "桃園市立永豐高級中學國中部", row1, 25),
            ("semester", "114 學年度上學期", row1, 40),  # 加寬處理
            ("exam_title", "第3次段考", row1, 15),
            ("course", "理化", row1, 10),
            ("grade", "國二", row2, 10),
            ("YEAR", "114上", row2, 15),
            ("test_range", "翰林ch5 ～ch 6", row2, 30)
        ]

        for key, default, parent, width in configs:
            f = ttk.Frame(parent);
            f.pack(side="left", padx=10)
            ttk.Label(f, text=f"{key}:").pack(side="left")
            var = tk.StringVar(value=default)
            ent = ttk.Entry(f, textvariable=var, width=width)
            ent.pack(side="left", padx=5)
            self.vars[key] = var

        # --- 3. 核心內容佈局 ---
        self.main_split = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, sashwidth=4, bg="#cccccc")
        self.main_split.pack(fill="both", expand=True, padx=10, pady=5)

        # 左側清單
        left_panel = ttk.Frame(self.main_split)
        self.tree = ttk.Treeview(left_panel, columns=("ID", "Score", "Ans", "Preview"), show="headings")
        self.tree.heading("ID", text="題號");
        self.tree.column("ID", width=50, anchor="center")
        self.tree.heading("Score", text="分值");
        self.tree.column("Score", width=60, anchor="center")
        self.tree.heading("Ans", text="答案");
        self.tree.column("Ans", width=60, anchor="center")
        self.tree.heading("Preview", text="題目與詳解內容摘要");
        self.tree.column("Preview", width=800, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        # 右側控制台
        right_panel = ttk.Frame(self.main_split)
        self.txt_preview = tk.Text(right_panel, height=8, font=("Arial", 11), bg="#fcfcfc", wrap="word")
        self.txt_preview.pack(fill="x", padx=10, pady=10)

        # 答案平衡
        manual_grp = ttk.LabelFrame(right_panel, text=" 題目編輯與選項平衡 ")
        manual_grp.pack(fill="x", padx=10, pady=5)
        self.correct_var = tk.IntVar();
        self.choice_entries = []
        for i in range(4):
            f = ttk.Frame(manual_grp);
            f.pack(fill="x", pady=2, padx=5)
            tk.Radiobutton(f, variable=self.correct_var, value=i, command=self.sync_to_obj).pack(side="left")
            ent = ttk.Entry(f, font=("Arial", 10));
            ent.pack(side="left", fill="x", expand=True, padx=5)
            ent.bind("<KeyRelease>", self.sync_to_obj);
            self.choice_entries.append(ent)

        ttk.Button(manual_grp, text="⚖️ 執行選項物理平衡", command=self.run_balance).pack(fill="x", pady=5, padx=30)
        self.lbl_ans_stats = ttk.Label(manual_grp, text="選項統計: A:0  B:0  C:0  D:0", font=("Arial", 11, "bold"),
                                       foreground="#1976D2")
        self.lbl_ans_stats.pack(pady=10)

        # 配分工具
        score_grp = ttk.LabelFrame(right_panel, text=" 分值設定工具 ")
        score_grp.pack(fill="x", padx=10, pady=5)
        btn_row = ttk.Frame(score_grp);
        btn_row.pack(pady=5)
        for s in [2, 2.5, 3, 4]:
            ttk.Button(btn_row, text=f"{s}分", width=7, command=lambda v=s: self.quick_assign_score(v)).pack(
                side="left", padx=3)
        ttk.Button(score_grp, text="🔢 區段批次配分 (無預設值)", command=self.open_batch_score).pack(fill="x", pady=5,
                                                                                                    padx=30)

        self.main_split.add(left_panel, width=950);
        self.main_split.add(right_panel, width=500)

        tk.Button(self.root, text="🚀 生成 Student / Teacher / Answer Key (同步校對)",
                  bg="#1B5E20", fg="white", font=("Arial", 12, "bold"),
                  command=self.start_generation).pack(pady=15, fill="x", padx=250)

    # --- 核心生成邏輯：支援動態計分說明 ---
    def start_generation(self):
        if not self.all_questions: return

        # 1. 自動依分數分段統計
        working_qs = [q for q in self.all_questions]
        sections = []
        if working_qs:
            group = [working_qs[0]]
            for q in working_qs[1:]:
                if q.score == group[0].score:
                    group.append(q)
                else:
                    sections.append(group); group = [q]
            sections.append(group)

        if self.shuffle_var.get():
            for g in sections: random.shuffle(g)

        # 2. 生成計分說明與考卷內文
        score_parts = [];
        curr_idx = 1;
        total_score = 0
        content_latex = []

        for i, group in enumerate(sections, 1):
            count = len(group);
            point = Decimal(str(group[0].score)).normalize()
            group_total = point * count;
            total_score += group_total
            end_idx = curr_idx + count - 1

            # 依照 Word 範本格式產出計分文字
            score_parts.append(f"第 {curr_idx}～{end_idx} 題，每題 {point} 分，共 {group_total} 分")

            # 考卷內文的分段標題
            content_latex.append(
                f"\\fullwidth{{\\section*{{第 {i} 部分：第 {curr_idx} 題至 {end_idx} 題，每題 {point} 分}}}}")

            for q in group:
                body = q.content.replace("\\question", "").strip()
                content_latex.append(f"\\question {body}\n\\begin{{choices}}")
                for idx, c in enumerate(q.choices):
                    cmd = "\\CorrectChoice" if idx == q.correct_idx else "\\choice"
                    content_latex.append(f"  {cmd} {c}")
                content_latex.append("\\end{choices}")
                if hasattr(q, 'solution') and q.solution:
                    content_latex.append(f"\\begin{{solution}} {q.solution} \\end{{solution}}")
            curr_idx += count

        # 三行式試卷說明注入 full_instruction_content
        full_instr = (
                f"\\textbf{{一、試卷說明：}} 本試卷均為單選題，共 {len(working_qs)} 題，請將答案劃記於答案卡上。\\\\\n"
                f"\\textbf{{二、計分方式：}} " + "；".join(score_parts) + f"，總分 {total_score} 分。\\\\\n"
                                                                       f"\\textbf{{三、注意：}} 如班級或座號填錯卡，將扣總分 5 分。"
        )

        # 3. 準備渲染數據
        data = {k: v.get() for k, v in self.vars.items()}
        data["year_code"] = self.vars["YEAR"].get()  # 修正對接模板 [[ year_code ]]
        data["questions_content"] = "\n".join(content_latex)
        data["full_instruction_content"] = full_instr

        template_path = os.path.join(project_root, "templates", "midterm_base.tex")

        try:
            # A. 學生卷 (逐一檢查狀態)
            data["print_answers_config"] = "\\noprintanswers"
            self.compiler.render_template(template_path, data, "student.tex")
            if not self.compiler.compile("student.tex"): raise Exception("學生卷 (student.tex) 編譯失敗")

            # B. 教師卷
            data["print_answers_config"] = "\\printanswers"
            self.compiler.render_template(template_path, data, "teacher.tex")
            if not self.compiler.compile("teacher.tex"): raise Exception("教師卷 (teacher.tex) 編譯失敗")

            # C. 解答表
            if not self.generate_answer_key(sections, data): raise Exception("解答表 (answers.tex) 編譯失敗")

            messagebox.showinfo("成功", f"PDF 已成功产出！\n總分：{total_score}")
        except Exception as e:
            messagebox.showerror("編譯錯誤", str(e))

    def generate_answer_key(self, sections, data):
            """生成結構與考卷一致的解答表 (2026-05-13 00:17 認可標題版，移除重複 YEAR)"""
            all_tables_latex = "";
            global_idx = 1
            for i, group in enumerate(sections, 1):
                s_num = global_idx;
                e_num = global_idx + len(group) - 1
                # 使用原生 \textbf 以避免 titlesec 衝突
                all_tables_latex += f"\\noindent\\textbf{{第 {i} 部分解答 (第 {s_num}-{e_num} 題，每題 {group[0].score} 分)}}\\\\ [0.5em]\n"

                for j in range(0, len(group), 10):
                    chunk = group[j:j + 10];
                    num_cols = len(chunk)
                    header = " & ".join([str(global_idx + j + k) for k in range(num_cols)])
                    ans = " & ".join([chr(65 + q.correct_idx) for q in chunk])

                    # 修正表格欄位定義
                    all_tables_latex += "\\begin{{tabular}}{{|*{{{}}}{{|p{{1.2cm}}|}}}}\\hline ".format(num_cols)
                    all_tables_latex += "\\rowcolor{{gray!20}} {} \\\\ \\hline ".format(header)
                    all_tables_latex += "{} \\\\ \\hline \\end{{tabular}} \\\\[1.5em]\n".format(ans)
                global_idx += len(group)

            data["answer_content"] = all_tables_latex

            # 標題格式修正：移除重複的 year_code，僅保留行政欄位與「解答表」字樣
            ans_tpl = r"""\documentclass[12pt]{article}
    \usepackage[paperwidth=21cm, paperheight=29.7cm, margin=2cm]{geometry}
    \usepackage{xeCJK, array, xcolor, colortbl}
    \setCJKmainfont[AutoFakeBold=true]{AR PL UKai TW}
    \begin{document}
    \begin{center}
        {\huge \textbf{[[ school_name ]]}} \\
        {\Large \textbf{[[ semester ]] [[ exam_title ]] [[ course ]] 解答表}}
    \end{center}
    \vspace{1.5em}
    [[ answer_content ]]
    \end{document}"""

            from jinja2 import Environment
            env = Environment(variable_start_string='[[', variable_end_string=']]')
            rendered = env.from_string(ans_tpl).render(**data)

            output_path = os.path.join(project_root, "outputs", "answers.tex")
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(rendered)
            return self.compiler.compile("answers.tex")

    # --- 功能輔助函數 ---
    def add_files(self):
        files = filedialog.askopenfilenames(filetypes=[("LaTeX", "*.tex")])
        if not files: return
        for f in files:
            qs = parse_latex_file(f)
            for q in qs: q.score = 2.0
            self.all_questions.extend(qs)
        self.update_stats()

    def update_stats(self):
        self.tree.delete(*self.tree.get_children())
        total = Decimal("0");
        counts = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
        for i, q in enumerate(self.all_questions):
            total += Decimal(str(q.score))
            ans = chr(65 + q.correct_idx);
            counts[ans] += 1
            self.tree.insert("", "end", values=(i + 1, q.score, ans, q.content[:150].strip()))
        self.lbl_ans_stats.config(text=f"選項統計: A:{counts['A']} B:{counts['B']} C:{counts['C']} D:{counts['D']}")
        self.lbl_total_score.config(text=f"當前總分: {total} / 100", foreground="black" if total == 100 else "red")

    def open_batch_score(self):
        win = tk.Toplevel(self.root);
        win.title("批次配分工具");
        win.geometry("380x300")
        f = ttk.Frame(win, padding=20);
        f.pack()
        inputs = [("起始題號:", ""), ("結束題號:", ""), ("分值:", "")]
        ents = []
        for i, (txt, d) in enumerate(inputs):
            ttk.Label(f, text=txt).grid(row=i, column=0, pady=10, sticky="e")
            e = ttk.Entry(f, width=15);
            e.grid(row=i, column=1, padx=10, pady=10);
            ents.append(e)

        def apply():
            try:
                s, e, v = int(ents[0].get()) - 1, int(ents[1].get()), float(ents[2].get())
                for i in range(max(0, s), min(len(self.all_questions), e)): self.all_questions[i].score = v
                self.update_stats();
                win.destroy()
            except:
                messagebox.showerror("錯誤", "格式不正確")

        ttk.Button(f, text="執行配分", command=apply).grid(row=3, columnspan=2, pady=20)

    def on_select(self, e):
        sel = self.tree.selection()
        if not sel: return
        self.current_q_idx = self.tree.index(sel[0])
        q = self.all_questions[self.current_q_idx]
        self.txt_preview.delete("1.0", "end");
        self.txt_preview.insert("end", q.content)
        for i, text in enumerate(q.choices):
            self.choice_entries[i].delete(0, "end");
            self.choice_entries[i].insert(0, text)
        self.correct_var.set(q.correct_idx)

    def sync_to_obj(self, e=None):
        if self.current_q_idx == -1: return
        q = self.all_questions[self.current_q_idx]
        q.choices = [ent.get() for ent in self.choice_entries]
        q.correct_idx = self.correct_var.get();
        self.update_stats()

    def quick_assign_score(self, val):
        if self.current_q_idx == -1: return
        self.all_questions[self.current_q_idx].score = val;
        self.update_stats()

    def run_balance(self):
        self.all_questions = balance_answers(self.all_questions);
        self.update_stats()


if __name__ == "__main__":
    root = tk.Tk();
    app = ExamGeneratorApp(root);
    root.mainloop()