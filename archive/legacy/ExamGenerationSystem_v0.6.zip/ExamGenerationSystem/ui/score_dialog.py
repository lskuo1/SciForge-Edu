import tkinter as tk
from tkinter import ttk


class ScoreBalanceDialog(tk.Toplevel):
    def __init__(self, parent, questions):
        super().__init__(parent)
        self.title("答案分佈統計與平衡調度")
        self.geometry("600x500")
        self.questions = questions
        self.result = False
        self.setup_ui()
        self.grab_set()  # 鎖定視窗

    def setup_ui(self):
        # 1. 統計面板
        stats_frame = ttk.LabelFrame(self, text="答案統計 (A-D)")
        stats_frame.pack(padx=10, pady=5, fill="x")

        self.stats_labels = {}
        for i, char in enumerate("ABCD"):
            lbl = ttk.Label(stats_frame, text=f"{char}: 0 題", font=("Arial", 12, "bold"))
            lbl.grid(row=0, column=i, padx=20, pady=10)
            self.stats_labels[char] = lbl

        # 2. 題目列表與答案選單
        list_frame = ttk.Frame(self)
        list_frame.pack(padx=10, pady=5, fill="both", expand=True)

        canvas = tk.Canvas(list_frame)
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        self.scrollable_frame = ttk.Frame(canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.ans_vars = []
        for i, q in enumerate(self.questions):
            f = ttk.Frame(self.scrollable_frame)
            f.pack(fill="x", pady=2)

            ttk.Label(f, text=f"第 {i + 1:02d} 題: {q.content[:30]}...", width=45).pack(side="left")

            var = tk.StringVar(value=chr(65 + q.correct_idx))
            cb = ttk.Combobox(f, textvariable=var, values=["A", "B", "C", "D"], width=3, state="readonly")
            cb.pack(side="right", padx=5)
            cb.bind("<<ComboboxSelected>>", lambda e: self.update_stats())
            self.ans_vars.append(var)

        self.update_stats()

        # 3. 確認按鈕
        ttk.Button(self, text="確認修改並生成 PDF", command=self.on_confirm).pack(pady=10)

    def update_stats(self):
        counts = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
        for var in self.ans_vars:
            counts[var.get()] += 1
        for char in "ABCD":
            self.stats_labels[char].config(text=f"{char}: {counts[char]} 題")

    def on_confirm(self):
        # 將修改後的答案套用回 Question 物件 (自動觸發 swap_answer)
        for i, var in enumerate(self.ans_vars):
            new_ans = var.get()
            self.questions[i].swap_answer(new_ans)
        self.result = True
        self.destroy()